# Subscribe Channel XploitSec
# Join Telegram channel : https://t.me/exploi7 for more tools